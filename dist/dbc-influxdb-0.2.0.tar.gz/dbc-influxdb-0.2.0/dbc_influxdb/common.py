# Column names of columns that are used as tags
tags = [
    'varname',
    'units',
    'raw_varname',
    'raw_units',
    'hpos',
    'vpos',
    'repl',
    'data_raw_freq',
    'freq',
    # 'freqfrom',
    'filegroup',
    'config_filetype',
    'data_version',
    'gain'
]
